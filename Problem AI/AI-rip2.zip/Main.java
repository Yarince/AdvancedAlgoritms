package problemAi;

import java.util.Scanner;

/**
 * Main.java
 * <p>
 * Owner Yarince Martis
 */
public class Main {


    public static void main(String[] argv) {
        process(new Scanner(System.in));
    }


    private static void process(Scanner in) {
        int fragments = in.nextInt();

        final long startTime = System.currentTimeMillis();
        for (int i = 1; i <= fragments; i++) {
            System.out.print("" + i + ": ");
            processCase(in);
        }

        final long endTime = System.currentTimeMillis();
        System.out.println("Total execution time: " + (endTime - startTime));
        System.out.println("Memmory = " + (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()));
    }

    private static void processCase(Scanner in) {
        String next = in.next();
        int words = Integer.parseInt(next);
        var sentences = new String[words];
        for (int i = 0; i < words; i++) {
            sentences[i] = in.next();
        }

        new Graph(sentences).getAllTopologicalSorts();
    }
}